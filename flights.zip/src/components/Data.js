import React from "react";
import { Form, Input, Button, Select, DatePicker } from 'antd';

function onChange(date, dateString) {
  console.log(date, dateString);
}

class Data extends React.Component {

  render() {
    return (
      <form onSubmit={this.props.onSubmit}>
        <div>
          <label htmlFor="title">Lugar de Origen</label>
          <Input type='text' id='originPlace' />
        </div>
        <div>
          <label htmlFor="title">Lugar de Destino</label>
          <Input type='text' id='destinationPlace' />
        </div>
        <div>
          <label htmlFor="title">Moneda</label>
          <Input type='text' id='money' />
        </div>
        <div>
          <label htmlFor="title">Fecha de Partida</label>
          <DatePicker onChange={onChange} id='startDate'/>
        </div>
        <div>
          <label htmlFor="title">Fecha de Regreso</label>
          <DatePicker onChange={onChange} id='endDate' />
        </div>
        
        <div>
          <button type="submit">Buscar</button>
        </div>
      </form>
    );
  }
}

export default Data;
