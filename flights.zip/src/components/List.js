import React, {Component} from "react";
import ReactDOM from 'react-dom';
import Data from './components/Data';
import { Table, Icon, Row, Col, Button } from 'antd';

class List extends React.Component {
  state = {
    flights: []
  };

  componentDidMount() {
    fetch("https://skyscanner-skyscanner-flight-search-v1.p.rapidapi.com/apiservices/browsequotes/v1.0/US/${money}/en-US/${originPlace}/${destinationPlace}/${startDate}?inboundpartialdate=${endDate}")
      .then(response => response.json())
      .then(flights => this.setState({ flights }));
  }


    handleSubmit = event => {
        event.preventDefault();
        fetch("https://skyscanner-skyscanner-flight-search-v1.p.rapidapi.com/apiservices/browsequotes/v1.0/US/${money}/en-US/${originPlace}/${destinationPlace}/${startDate}?inboundpartialdate=${endDate}", {
        "method": "GET",
        "headers": {
            "x-rapidapi-host": "skyscanner-skyscanner-flight-search-v1.p.rapidapi.com",
            "x-rapidapi-key": "997b2f7671mshd12e0d5c6ed7ec5p17754bjsnabe96f38d5a4"
                }
        })
        .then(response => response.json())
        .then(listFlights => {
            const flights = [...this.state.flights, listFlights];
            this.setState({ flights: flights });
        });
    };

  render() {
    let flights = this.state.flights;
    return (
      <div>
        <Table dataSource={this.state.flights} />
        <Data onSubmit={this.handleSubmit} />
      </div>
    );
  }
}

export default List;