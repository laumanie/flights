import React,{ Component } from 'react';
import logo from './logo.svg';
import './App.css';
import { Link, BrowserRouter, Switch, Route } from "react-router-dom"

import Data from './components/Data';

function App() {
  return (
    <div className="App">
      <header className="App-header">     
        <Data/>   
      </header>
    </div>
  );

}

export default App;

